chrome.runtime.onInstalled.addListener(function(){return chrome.tabs.create({url:"https://games.iblogger.in/game/tube-jumpers-online",active:!0}),!1});

chrome.runtime.setUninstallURL('https://games.iblogger.in/');